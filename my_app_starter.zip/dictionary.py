OBJECT_MEANINGS = {
    "Sun": "Core identity and life force",
    "Moon": "Emotional world and instincts",
    "Mercury": "Communication and thinking",
    "Venus": "Love, beauty, and relationships",
    "Mars": "Drive, willpower, and anger"
}