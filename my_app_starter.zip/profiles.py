from dictionary import OBJECT_MEANINGS

def format_planet_profile(planet_name):
    meaning = OBJECT_MEANINGS.get(planet_name, "Unknown")
    return f"### {planet_name}\n\n**Meaning:** {meaning}"